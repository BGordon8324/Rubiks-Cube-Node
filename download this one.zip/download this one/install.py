# -- Installer ----------------------------------------------------------------
import maya.cmds as cmds
import os
import shutil
import maya.mel as mel
from pathlib import Path


def onMayaDroppedPythonFile(*args):

    installer_dir = Path(__file__).parent

    user_app_dir = Path(
        cmds.internalVar(
            userAppDir=True))

    scripts_dir = Path(
        cmds.internalVar(
            userScriptDir=True))

    plugin_dir = (
        user_app_dir /
        "plug-ins")

    plugin_dir.mkdir(
        parents=True,
        exist_ok=True)

    #
    # Install plugin
    #

    plugin_src = (
        installer_dir /
        "RubiksCubeNode.mll")

    plugin_dst = (
        plugin_dir /
        "RubiksCubeNode.mll")

    if cmds.pluginInfo(
            "RubiksCubeNode.mll",
            query=True,
            loaded=True):

        cmds.unloadPlugin(
            "RubiksCubeNode.mll")

    shutil.copy2(
        plugin_src,
        plugin_dst)

    #
    # Install tool
    #

    tool_src = (
        installer_dir /
        "Rubiks Cube Tool")

    tool_dst = (
        scripts_dir /
        "Rubiks Cube Tool")

    if tool_dst.exists():

        shutil.rmtree(
            tool_dst)

    shutil.copytree(
        tool_src,
        tool_dst)

    #
    # Install icons
    #

    icons_src = (
        installer_dir /
        "icons")

    icons_dst = (
        scripts_dir /
        "icons")

    if icons_dst.exists():

        shutil.rmtree(
            icons_dst)

    shutil.copytree(
        icons_src,
        icons_dst)
        
        
    #
    # Install Cube Rig project
    #
    
    projects_dir = (
    Path(cmds.internalVar(userAppDir=True)) /
    "projects")

    projects_dir.mkdir(
        parents=True,
        exist_ok=True)
        
    project_src = (
    installer_dir /
    "Rubiks Cube Rig")

    project_dst = (
        projects_dir /
        "Rubiks Cube Rig")
    
    if not project_dst.exists():
    
        shutil.copytree(
            project_src,
            project_dst)

    #
    # Load plugin
    #

    cmds.loadPlugin(
        str(plugin_dst))

    cmds.pluginInfo(
        "RubiksCubeNode.mll",
        edit=True,
        autoload=True)

    #
    # Build shelf
    #

    shelf_name = "RubiksCube"

    if not cmds.shelfLayout(
            shelf_name,
            exists=True):

        mel.eval(
            'global string $gShelfTopLevel; '
            'shelfLayout -manage 1 -p $gShelfTopLevel "{}"'.format(
                shelf_name))

    existing = (
        cmds.shelfLayout(
            shelf_name,
            query=True,
            childArray=True)
        or [])

    for child in existing:

        cmds.deleteUI(child)

    icon = str(
        scripts_dir /
        "icons" /
        "cube icon.png")

    command = '''
import os
import sys
import maya.cmds as cmds

toolPath = os.path.join(
    cmds.internalVar(userScriptDir=True),
    "Rubiks Cube Tool")

if toolPath not in sys.path:
    sys.path.insert(0, toolPath)

import RubiksCubeData
import RubiksCubeIO
import RubiksCubeIOUI

RubiksCubeIOUI.RubiksCubeIOUI().show()
'''

    cmds.shelfButton(
        parent=shelf_name,
        label="Rubiks Cube",
        annotation="Open Rubiks Cube Save/Load Tool",
        image=icon,
        sourceType="python",
        style="iconAndTextVertical",
        command=command)

    mel.eval(
        'global string $gShelfTopLevel; '
        'shelfTabLayout -e -selectTab "{}" $gShelfTopLevel;'.format(
            shelf_name))